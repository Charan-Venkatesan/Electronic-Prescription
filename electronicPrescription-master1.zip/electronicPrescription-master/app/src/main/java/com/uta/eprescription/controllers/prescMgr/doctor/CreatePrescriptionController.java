package com.uta.eprescription.controllers.prescMgr.doctor;

public class CreatePrescriptionController {

    public void getPrescID(String userid)
    {

    }
}
