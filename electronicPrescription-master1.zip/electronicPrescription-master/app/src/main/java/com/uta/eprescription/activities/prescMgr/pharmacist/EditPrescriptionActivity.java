package com.uta.eprescription.activities.prescMgr.pharmacist;

public class EditPrescriptionActivity {
}
