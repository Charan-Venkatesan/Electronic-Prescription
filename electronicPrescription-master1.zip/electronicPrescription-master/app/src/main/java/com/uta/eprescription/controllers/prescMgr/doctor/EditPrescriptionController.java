package com.uta.eprescription.controllers.prescMgr.doctor;

public class EditPrescriptionController {
}
