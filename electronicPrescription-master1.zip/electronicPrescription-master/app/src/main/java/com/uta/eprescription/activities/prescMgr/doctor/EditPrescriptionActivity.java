package com.uta.eprescription.activities.prescMgr.doctor;

public class EditPrescriptionActivity {
}
