package com.uta.eprescription.controllers.prescMgr.patient;

public class PatientController {
}
