package com.uta.eprescription.controllers.prescMgr.common;

public class ViewPrescriptionController {
}
