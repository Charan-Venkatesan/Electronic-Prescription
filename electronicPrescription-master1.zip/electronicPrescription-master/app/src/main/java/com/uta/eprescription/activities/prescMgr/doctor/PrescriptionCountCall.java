package com.uta.eprescription.activities.prescMgr.doctor;

public interface PrescriptionCountCall<Long> {
    void callback(Long count);
}
