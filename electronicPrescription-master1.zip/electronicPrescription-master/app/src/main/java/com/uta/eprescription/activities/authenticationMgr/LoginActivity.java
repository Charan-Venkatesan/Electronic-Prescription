package com.uta.eprescription.activities.authenticationMgr;

public class LoginActivity {
}
